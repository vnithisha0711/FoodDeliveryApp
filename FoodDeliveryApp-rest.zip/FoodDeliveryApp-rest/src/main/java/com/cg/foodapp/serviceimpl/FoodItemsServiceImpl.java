package com.cg.foodapp.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.foodapp.dto.FoodItemsDTO;
import com.cg.foodapp.entity.FoodItems;
import com.cg.foodapp.entity.Restaurants;
import com.cg.foodapp.repository.FoodItemsRepository;
import com.cg.foodapp.service.FoodItemsService;

@Service
public class FoodItemsServiceImpl implements FoodItemsService {
	@Autowired
	private FoodItemsRepository foodItemsRepository;

	
	
	@Override
	public FoodItemsDTO addFoodItems(FoodItemsDTO foodItemsDTO) {

		FoodItems fooditems = new FoodItems();
		Restaurants rest=new Restaurants();
		rest.setId(foodItemsDTO.getRestaurantId());
		fooditems.setRestaurants(rest);
		fooditems.setName(foodItemsDTO.getName());
		fooditems.setPrice(foodItemsDTO.getPrice());
		fooditems.setQuantity(foodItemsDTO.getQuantity());	
		
		FoodItems fooditemssave=foodItemsRepository.save(fooditems);
		foodItemsDTO.setFoodId(fooditemssave.getId());
		return foodItemsDTO;
	}

	@Override
	public FoodItemsDTO updateFoodItems(FoodItemsDTO foodItemsDTO) {

		FoodItems fooditems = new FoodItems();
		Restaurants rest=new Restaurants();
		rest.setId(foodItemsDTO.getRestaurantId());
		fooditems.setRestaurants(rest);
		fooditems.setName(foodItemsDTO.getName());
		fooditems.setPrice(foodItemsDTO.getPrice());
		fooditems.setQuantity(foodItemsDTO.getQuantity());	
		fooditems.setId(foodItemsDTO.getFoodId());
		
		foodItemsRepository.save(fooditems);		
		return foodItemsDTO;
	}

	@Override
	public boolean deleteFoodItems(FoodItemsDTO foodItemsDTO) {

		FoodItems fooditems = new FoodItems();
		fooditems.setId(foodItemsDTO.getFoodId());
		foodItemsRepository.delete(fooditems);
		return true;
	}

	@Override
	public FoodItemsDTO getById(int id) {

		Optional<FoodItems> fooditems = foodItemsRepository.findById(id);
		if (fooditems.isPresent()) {
			FoodItemsDTO dto = new FoodItemsDTO();
			BeanUtils.copyProperties(fooditems.get(), dto);
			return dto;
		}
		return null;
	}

	@Override
	public List<FoodItemsDTO> findAll() {

		Iterable<FoodItems> fooditems = foodItemsRepository.findAll();
		List<FoodItemsDTO> dtos = new ArrayList<>();
		for (FoodItems fooditem : fooditems) {
			FoodItemsDTO dto = new FoodItemsDTO();
			BeanUtils.copyProperties(fooditem, dto);
			dtos.add(dto);
		}
		return dtos;
	}

}
