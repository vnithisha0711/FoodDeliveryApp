package com.cg.foodapp.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.foodapp.dto.RestaurantsDTO;
import com.cg.foodapp.entity.Restaurants;
import com.cg.foodapp.entity.User;
import com.cg.foodapp.exceptions.RestaurantNotAvailableException;
import com.cg.foodapp.repository.RestaurantsRepository;
import com.cg.foodapp.repository.UserRepository;
import com.cg.foodapp.service.RestaurantsService;

@Service
public class RestaurantsServiceImpl implements RestaurantsService {
	@Autowired
	private RestaurantsRepository restaurantRepository;

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public RestaurantsDTO addRestaurants(RestaurantsDTO restaurantsDto) {

		User user=new User();
		user.setPassword(restaurantsDto.getPassword());
		user.setRole("OWNER");
		user.setUsername(restaurantsDto.getUsername());		

		User userSave=userRepository.save(user);
		Restaurants restaurants = new Restaurants();
		restaurants.setUserId(userSave);
		restaurants.setName(restaurantsDto.getName());
		restaurants.setEmailId(restaurantsDto.getEmailId());
		restaurants.setContactNo(restaurantsDto.getContactNo());
        //restaurants.setId(restaurantsDto.getId());
        restaurants.setLocation(restaurantsDto.getLocation());
		
        Restaurants restaurantsave=restaurantRepository.save(restaurants);
        restaurantsDto.setUserId(userSave.getUserId());
        restaurantsDto.setId(restaurantsave.getId());
		return restaurantsDto;
	}

	@Override
	public RestaurantsDTO updateRestaurants(RestaurantsDTO restaurantsDTO) {

		Restaurants restaurants = new Restaurants();
		User user=new User();
		user.setUserId(restaurantsDTO.getUserId());
		restaurants.setUserId(user);
		restaurants.setId(restaurantsDTO.getId());
		restaurants.setName(restaurantsDTO.getName());
		restaurants.setEmailId(restaurantsDTO.getEmailId());
		restaurants.setContactNo(restaurantsDTO.getContactNo());
		restaurants.setLocation(restaurantsDTO.getLocation());
		
		restaurantRepository.save(restaurants);
		return restaurantsDTO;
	}

	@Override
	public boolean deleteRestaurants(RestaurantsDTO restaurantsDTO) {

		Restaurants restaurants = new Restaurants();
		restaurants.setId(restaurantsDTO.getId());
		restaurantRepository.delete(restaurants);
		return true;//write logic
	}

	@Override
	public RestaurantsDTO getById(int id) {

		Optional<Restaurants> restaurants = restaurantRepository.findById(id);
		if (restaurants.isPresent()) {
			RestaurantsDTO dto = new RestaurantsDTO();
			BeanUtils.copyProperties(restaurants.get(), dto);
			return dto;
		}
		throw new RestaurantNotAvailableException("Restaurant not Available");
	}

	@Override
	public List<RestaurantsDTO> findAll() {

		Iterable<Restaurants> restaurants = restaurantRepository.findAll();
		List<RestaurantsDTO> dtos = new ArrayList<>();
		for (Restaurants restaurant : restaurants) {
			RestaurantsDTO dto = new RestaurantsDTO();
			BeanUtils.copyProperties(restaurant, dto);
			dtos.add(dto);
		}
		return dtos;
	}

}
