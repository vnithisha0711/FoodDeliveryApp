package com.cg.foodapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.foodapp.dto.CustomersDTO;
import com.cg.foodapp.dto.OrdersDTO;
import com.cg.foodapp.dto.RestaurantsDTO;
import com.cg.foodapp.service.CustomersService;
import com.cg.foodapp.service.OrdersService;
import com.cg.foodapp.service.RestaurantsService;

@SpringBootTest
class FoodDeliveryAppApplicationTests {

	@Autowired
	private RestaurantsService restaurantsService;

	@Autowired
	private CustomersService customersService;

	@Autowired
	private OrdersService ordersService;

	@Test
	void testgetByRestaurantId() {
		RestaurantsDTO c = restaurantsService.getById(3);
		assertEquals("stuv", c.getName());
		assertEquals("hyd", c.getLocation());
	}

	@Test
	void testgetByCustomerId() {
		CustomersDTO d = customersService.getById(5);
		assertEquals("abc", d.getName());
	}

	@Test
	void testgetByOrderId() {
		OrdersDTO o = ordersService.getById(6);
		assertEquals("delivered", o.getStatus());
	}

}
